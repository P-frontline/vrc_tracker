import axios from "axios";

const client = axios.create({
  baseURL: "https://api.vrchat.cloud/api/1",
  withCredentials: true,
  headers: {
	  "User-Agent": "VRCT",
  }
});

async function login(username, password) {
  const auth = Buffer.from(`${username}:${password}`).toString("base64");

  // 1단계: 쿠키 확보용 요청
  await client.get("/auth/user");

  // 2단계: 실제 인증 요청
  const res = await client.get("/auth/user", {
    headers: {
      Authorization: `Basic ${auth}`,
    },
  });

  return res.data;
}


login("YOUR-ID", "YOUR-PASSWORD")
  .then(user => console.log("로그인 성공:", user))
  .catch(err => console.error(err));
